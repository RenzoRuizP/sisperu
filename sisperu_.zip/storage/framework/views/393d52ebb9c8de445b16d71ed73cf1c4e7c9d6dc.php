 
 

<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_institucion"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>TIPO INSTITUCIÓN</th>
                        <th>NOMBRE</th>
                        <th>TELÉFONO</th>
                        <th>DISTRITO</th>
                        <th>DIRECCIÓN</th>
                        <th>EMPRESA ID</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $instituciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institucion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($institucion->id); ?></td>

                            <?php
                                if($institucion->tipo_institucion == 1)
                                    echo '<td>CLÍNICA</td>';
                                if($institucion->tipo_institucion == 2)
                                    echo '<td>HOSPITAL</td>';
                                if($institucion->tipo_institucion == 3)
                                    echo '<td>CONSULTORIO PARTICULAR</td>';
                            ?>
 
                            <td><?php echo e($institucion->nombre); ?></td>
                            <td><?php echo e($institucion->telefono); ?></td>
                            <td><?php echo e($institucion->distrito->nombre); ?></td>
                            <td><?php echo e($institucion->direccion); ?></td>
                            <td><?php echo e($institucion->empresa->nombre); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id="<?php echo e($institucion->id); ?>" 
                                data-tipo_institucion="<?php echo e($institucion->tipo_institucion); ?>" 
                                data-nombre="<?php echo e($institucion->nombre); ?>" 
                                data-telefono="<?php echo e($institucion->telefono); ?>" 
                                data-distrito_id ="<?php echo e($institucion->distrito_id); ?>"
                                data-direccion ="<?php echo e($institucion->direccion); ?>"
                                data-empresa_id ="<?php echo e($institucion->empresa_id); ?>"
                                >Editar</button>
                                
                                <button data-id="<?php echo e($institucion->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="institucion_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_institucion">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_institucion" action="<?php echo e(url('mantenimiento/institucion')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <select name="tipo_institucion" ID="tipo_institucion" class="form-control">
                                    <option>Tipo institución</option>
                                <?php $__currentLoopData = $tipoInstituciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($tipo); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                        </div>
                        <div class="col-sm-6">
                            <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre*">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <input type="text" name="telefono" id="telefono" class="form-control" placeholder="Teléfono*">
                            
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            Departamento
                            <select name="departamento_id" id="departamento_id" class="form-control">
                                <option>Elige</option>
                                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($departamento->id); ?>"><?php echo e($departamento->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            Provincia
                            <select name="provincia_id" id="provincia_id" class="form-control">
                                
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            Distrito
                            <select name="distrito_id" id="distrito_id" class="form-control">
                                
                            </select>
                        </div>
                    </div>
                    <div class="form-row">     
                        <div class="form-group col-md-12">
                            <input type="text" name="direccion" class="form-control" placeholder="Dirección*">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <select name="empresa_id" id="empresa_id" class="form-control">
                                <option>Empresa</option>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_institucion" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/institucion/index.blade.php ENDPATH**/ ?>