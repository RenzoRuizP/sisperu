 
 

<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_usuario"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>PASSWORD</th>
                        <th>TRABAJADOR ID</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($usuario->id); ?></td>
                            <td><?php echo e($usuario->name); ?></td>
                            <td><?php echo e($usuario->password); ?></td>
                            <td>
                                <?php echo e($user_->trabajador->persona->nombres.' '.$user_->trabajador->persona->apellidos); ?>

                            </td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id="<?php echo e($usuario->id); ?>" 
                                data-name="<?php echo e($usuario->name); ?>" 
                                data-password="<?php echo e($usuario->password); ?>" 
                                data-trabajador_id ="<?php echo e($usuario->trabajador_id); ?>"
                                >Editar</button>
                                
                                <button data-id="<?php echo e($usuario->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="usuario_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_usuario">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_usuario" action="<?php echo e(url('mantenimiento/usuario')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                        <div class="form-group">
                        Tipo Documento 
                            <select name="tipo_documento" class="form-control">
                                <option>Elige</option>
                                <option value="0">RUC</option>
                                <option value="1">DNI</option>
                                <option value="2">CARNET DE EXTRANJERIA</option>
                            </select>
                        
                    </div>
                    <div class="form-group">
                        número de documento <input type="text" id="numero_documento" name="numero_documento" class="form-control" maxlength="11" onkeypress="ValidaSoloNumeros();">
                    </div>
                    <div class="form-group">
                        Nombres: <input type="text" name="nombres" class="form-control" disabled="true">
                    </div>
                    <div class="form-group">
                        Apellidos: <input type="text" name="apellidos" class="form-control" disabled="true">
                    </div>
                    <div class="form-group">
                        Nombre usuario: <input type="text" name="nombre_usuario" class="form-control">
                    </div>
                    <div class="form-group">
                        Password: <input type="text" name="repetir_clave" class="form-control">
                    </div>
                    <div class="form-group">
                        Repetir password: <input type="text" name="repetir_clave" class="form-control">
                    </div>

                    <!--
                    <div class="form-group">
                    </div>
                    <div class="form-group">
                        Nombre: <input type="text" name="name" class="form-control">
                    </div>
                    <div class="form-group">
                        Password: <input type="text" name="clave" class="form-control">
                    </div>
                    <div class="form-group">
                    Trabajador   <select class="form-control" name="trabajador_id">
                                <option>Elige</option>                        
                                <?php $__currentLoopData = $trabajadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($trabajador->id); ?>"><?php echo e($trabajador->persona->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    -->
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_usuario" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/usuario/index.blade.php ENDPATH**/ ?>