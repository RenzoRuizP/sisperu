<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_detalle_anamnesis"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ANAMNESIS</th>
                        <th>NOMBRE CAMPO</th>
                        <th>VALOR</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detalleAnamnesis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalleAnamnesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($detalleAnamnesi->id); ?></td>
                            <td><?php echo e($detalleAnamnesi->anamnesis_id); ?></td>
                            <td><?php echo e($detalleAnamnesi->nombreCampo); ?></td>
                            <td><?php echo e($detalleAnamnesi->valor); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" data-id="<?php echo e($detalleAnamnesi->id); ?>">Editar</button>
                                <button data-id="<?php echo e($detalleAnamnesi->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="detalle_anamnesis_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_detalle_anamnesis">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_detalle_anamnesis" action="<?php echo e(url('mantenimiento/detalleanamnesis')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <select class="form-control" name="anamnesis_id" id="anamnesis_id">
                                <option>Elige anamnesis</option>
                                
                                <?php $__currentLoopData = $anamnesis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anamnesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($anamnesi->id); ?>"><?php echo e($anamnesi->id); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input type="text" name="nombreCampo" class="form-control" placeholder="Nombre del campo">
                        </div>
                        <div class="form-group col-md-6">
                            <input type="text" name="valor" class="form-control" placeholder="Valor">
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_detalle_anamnesis" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/detalleanamnesis/index.blade.php ENDPATH**/ ?>