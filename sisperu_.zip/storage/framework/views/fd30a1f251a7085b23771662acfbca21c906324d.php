<!-- Footer Start -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6">
                    Desarrollado por SisPeru
                </div>
                <div class="col-md-6">
                    <div class="text-md-right footer-links d-none d-md-block">
                        2020 © Todos los derechos reservados a Medical Audicion
                    </div>
                </div>
            </div>
        </div>
    </footer>
<!-- end Footer --><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/includes/footer.blade.php ENDPATH**/ ?>