<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_anamnesis"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>FECHA</th>
                        <th>USUARIO ID</th>
                        <th>PACIENTE ID</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $anamnesis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anamnesi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($anamnesi->id); ?></td>
                            <td><?php echo e($anamnesi->fecha); ?></td>
                            <td>
                                <?php echo e($anamnesi->user->trabajador->persona->nombres." ".$anamnesi->user->trabajador->persona->apellidos); ?>

                            </td>
                            <td>
                                <?php echo e($anamnesi->paciente->persona->nombres." ".$anamnesi->paciente->persona->apellidos); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" data-id="<?php echo e($anamnesi->id); ?>">Editar</button>
                                <button data-id="<?php echo e($anamnesi->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="anamnesis_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_anamnesis">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_anamnesis" action="<?php echo e(url('mantenimiento/anamnesis')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <input type="date" name="fecha" id="fecha" class="form-control">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <select class="form-control" name="usuario_id" id="usuario_id">
                                <option>Elige usuario</option>
                                
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($usuario->id); ?>"><?php echo e($usuario->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <select class="form-control" name="paciente_id" id="paciente_id">
                                <option>Elige paciente</option>
                                
                                <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($paciente->id); ?>"><?php echo e($paciente->persona->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_anamnesis" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/anamnesis/index.blade.php ENDPATH**/ ?>