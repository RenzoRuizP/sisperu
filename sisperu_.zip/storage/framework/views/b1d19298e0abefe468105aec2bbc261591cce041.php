<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_producto"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>CÓDIGO</th>
                        <th>NOMBRE</th>
                        <th>CATACTERISTICA</th>
                        <th>CATEGORIA_ID</th>
                        <th>MARCA_ID</th>
                        <th>PROVEEDOR_ID</th>
                        <th>FOTO</th>
                        <th>UNIDAD X BASE</th>
                        <th>COSTO PROVEEDOR</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($producto->id); ?></td>
                            <td><?php echo e($producto->codigo); ?></td>
                            <td><?php echo e($producto->nombre); ?></td>
                            <td><?php echo e($producto->caracteristicas); ?></td>
                            <td><?php echo e($producto_->categoria->nombre); ?></td>
                            <td><?php echo e($producto->marca->nombre); ?></td>
                            <td><?php echo e($producto_->proveedor->nombre); ?></td>
                            <td>
                                    <img src="<?php echo e(asset('storage/'.$producto->foto)); ?>" height="60">
                            </td>
                            <td><?php echo e($producto->unidad_por_base); ?></td>
                            <td><?php echo e($producto->costo_proveedor); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id ="<?php echo e($producto->id); ?>" 
                                data-codigo ="<?php echo e($producto->codigo); ?>" 
                                data-nombre ="<?php echo e($producto->nombre); ?>" 
                                data-caracteristica ="<?php echo e($producto->caracteristicas); ?>"
                                data-categoria_id ="<?php echo e($producto->categoria_id); ?>"
                                data-marca_id ="<?php echo e($producto->marca_id); ?>"
                                data-proveedor_id ="<?php echo e($producto->proveedor_id); ?>"
                                data-foto ="<?php echo e($producto->foto); ?>"
                                data-unidad_por_base ="<?php echo e($producto->unidad_por_base); ?>"
                                data-costo_proveedor ="<?php echo e($producto->costo_proveedor); ?>"
                                >Editar</button>
                                
                                <button data-id="<?php echo e($producto->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="producto_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_producto">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_producto" action="<?php echo e(url('mantenimiento/producto')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group row">
                        <div class="col-sm-10">
                            Código: <input type="text" name="codigo" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            Nombre: <input type="text" name="nombre" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            Característica: <input type="text" name="caracteristicas" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">

                            Categoria
                                <select name="categoria_id" class="form-control">
                                    <option>Elige</option>
                                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">

                            Marca   <select name="marca_id" class="form-control">
                                        <option>Elige</option>
                                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->nombre); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            Proveedor<select name="proveedor_id" class="form-control">
                                        <option>Elige</option>
                                    <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($proveedor->id); ?>"><?php echo e($proveedor->nombre); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            foto: <input type="file" name="imagen_foto" id="imagen_foto" class="form-control-file">
                            <div>
                                <img src="" id="img_preview_foto" class="w-100">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            unidad x base: <input type="text" name="unidad_por_base" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-10">
                            costo pronveedor: <input type="text" name="costo_proveedor" class=" form-control">
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_producto" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/producto/index.blade.php ENDPATH**/ ?>