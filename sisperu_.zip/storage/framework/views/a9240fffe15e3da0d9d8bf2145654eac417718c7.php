<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_producto"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>CÓDIGO</th>
                        <th>NOMBRE</th>
                        <th>CATACTERISTICA</th>
                        <th>CATEGORIA_ID</th>
                        <th>MARCA_ID</th>
                        <th>PROVEEDOR_ID</th>
                        <th>FOTO</th>
                        <th>UNIDAD X BASE</th>
                        <th>COSTO PROVEEDOR</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($producto->id); ?></td>
                            <td><?php echo e($producto->codigo); ?></td>
                            <td><?php echo e($producto->nombre); ?></td>
                            <td><?php echo e($producto->caracteristica); ?></td>
                            <td><?php echo e($producto->categoria_id); ?></td>
                            <td><?php echo e($producto->marca_id); ?></td>
                            <td><?php echo e($producto->proveedor_id); ?></td>
                            <td><?php echo e($producto->foto); ?></td>
                            <td><?php echo e($producto->unidad_por_base); ?></td>
                            <td><?php echo e($producto->costo_proveedor); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id ="<?php echo e($producto->id); ?>" 
                                data-codigo ="<?php echo e($producto->codigo); ?>" 
                                data-nombre ="<?php echo e($producto->nombre); ?>" 
                                data-caracteristica ="<?php echo e($producto->caracteristica); ?>"
                                data-categoria_id ="<?php echo e($producto->categoria_id); ?>"
                                data-marca_id ="<?php echo e($producto->marca_id); ?>"
                                data-proveedor_id ="<?php echo e($producto->proveedor_id); ?>"
                                data-foto ="<?php echo e($producto->foto); ?>"
                                data-unidad_por_base ="<?php echo e($producto->unidad_por_base); ?>"
                                data-costo_proveedor ="<?php echo e($producto->costo_proveedor); ?>"
                                >Editar</button>
                                
                                <button data-id="<?php echo e($producto->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="producto_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_producto">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_producto" action="<?php echo e(url('mantenimiento/producto')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    Código: <input type="text" name="codigo" class="form-control">
                    Nombre: <input type="text" name="nombre" class="form-control">
                    Característica: <input type="text" name="caracteristicas" class="form-control">

                    Categoria_id: <input type="text" name="categoria_id" class="form-control">
                    marca_id: <input type="text" name="marca_id" class="form-control">

                    proveedor_id: <input type="text" name="proveedor_id" class="form-control">
                    foto: <input type="text" name="foto" class="form-control">
                    unidad x base: <input type="text" name="unidad_por_base" class="form-control">
                    costo pronveedor: <input type="text" name="costo_proveedor" class="form-control">

                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_producto" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu\resources\views/admin/producto/index.blade.php ENDPATH**/ ?>