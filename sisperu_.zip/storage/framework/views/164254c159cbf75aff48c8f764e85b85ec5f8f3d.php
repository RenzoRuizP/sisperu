 
 

<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_distribuidor"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>tipo</th>
                        <th>EMPRESA ID</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $distribuidores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $distribuidor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($distribuidor->id); ?></td>
                            
                                <?php
                                    if($distribuidor->tipo == 1)
                                        echo '<td>A</td>';
                                    if($distribuidor->tipo == 2)
                                        echo '<td>B</td>';
                                    if($distribuidor->tipo == 3)
                                        echo '<td>C</td>';
                                    if($distribuidor->tipo == 4)
                                        echo '<td>PARTNER</td>';
                                ?>
                            
                            <td><?php echo e($distribuidor->empresa->nombre); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id="<?php echo e($distribuidor->id); ?>" 
                                data-tipo="<?php echo e($distribuidor->tipo); ?>" 
                                data-empresa_id="<?php echo e($distribuidor->empresa_id); ?>" 
                                >Editar</button>
                                
                                <button data-id="<?php echo e($distribuidor->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="distribuidor_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_distribuidor">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_distribuidor" action="<?php echo e(url('mantenimiento/distribuidor')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group row">
                        <div class="col-sm-6">
                            <select name="tipo" id="tipo" class="form-control">
                                    <option>Tipo ditribuidor</option>
                                <?php $__currentLoopData = $tipoDistribuidores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($tipo); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                        </div>
                        <div class="col-sm-6">
                            <select name="empresa_id" id="empresa_id" class="form-control">
                                    <option>Empresa</option>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_distribuidor" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/distribuidor/index.blade.php ENDPATH**/ ?>