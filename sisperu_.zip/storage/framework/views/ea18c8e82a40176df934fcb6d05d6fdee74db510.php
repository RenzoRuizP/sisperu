<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_sucursal"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>DISTRITO</th>
                        <th>DIRECCIÓN</th>
                        <th>TELÉFONO</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sucursal->id); ?></td>
                            <td><?php echo e($sucursal->nombre); ?></td>
                            <td><?php echo e($sucursal->distrito->nombre); ?></td>
                            <td><?php echo e($sucursal->direccion); ?></td>
                            <td><?php echo e($sucursal->telefono); ?></td>
                            <td><?php echo e($sucursal->tipo_sucursal); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id="<?php echo e($sucursal->id); ?>" 
                                data-nombre="<?php echo e($sucursal->nombre); ?>" 
                                data-distrito_id="<?php echo e($sucursal->distrito_id); ?>" 
                                data-direccion ="<?php echo e($sucursal->direccion); ?>"
                                data-telefono ="<?php echo e($sucursal->telefono); ?>"
                                data-tipo_sucursal ="<?php echo e($sucursal->tipo_sucursal); ?>">Editar</button>
                                
                                <button data-id="<?php echo e($sucursal->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="sucursal_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_sucursal">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_sucursal" action="<?php echo e(url('mantenimiento/sucursal')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-group">
                        Nombre: <input type="text" name="nombre" class="form-control">
                    </div>
                    <div class="form-group">
                        Departamento:
                            <select name="departamento_id" id = "departamento_id" class="form-control">
                                <option>Elige</option>
                                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($departamento->id); ?>"><?php echo e($departamento->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        Provincia:
                            <select name="provincia_id" id="provincia_id" class="form-control">
                                
                            </select>
                    </div>
                    <div class="form-group">
                        Distrito:
                            <select name="distrito_id" id="distrito_id" class="form-control">
                                
                            </select>
                    </div>
                    <div class="form-group">
                        Dirección: <input type="text" name="direccion" class="form-control">
                    </div>
                    <div class="form-group">
                        Teléfono: <input type="text" name="telefono" class="form-control">
                    </div>
                    <div class="form-group">
                        Tipo sucursal: <input type="text" name="tipo_sucursal" class="form-control">
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_sucursal" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/sucursal/index.blade.php ENDPATH**/ ?>