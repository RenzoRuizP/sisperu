 
 

<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_empresa"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>NOMBRE</th>
                        <th>RAZÓN SOCIAL</th>
                        <th>DISTRITO ID</th>
                        <th>DIRECCIÓN</th>
                        <th>RUC</th>
                        <th>TELÉFONO</th>
                        <th>CORREO</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($empresa->id); ?></td>
                            <td><?php echo e($empresa->nombre); ?></td>
                            <td><?php echo e($empresa->razon_social); ?></td>
                            <td><?php echo e($empresa->distrito->nombre); ?></td>
                            <td><?php echo e($empresa->direccion); ?></td>
                            <td><?php echo e($empresa->ruc); ?></td>
                            <td><?php echo e($empresa->telefono); ?></td>
                            <td><?php echo e($empresa->correo); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id="<?php echo e($empresa->id); ?>" 
                                data-nombre="<?php echo e($empresa->nombre); ?>" 
                                data-razon_social="<?php echo e($empresa->razon_social); ?>" 
                                data-distrito_id ="<?php echo e($empresa->distrito_id); ?>"
                                data-direccion ="<?php echo e($empresa->direccion); ?>"
                                data-ruc ="<?php echo e($empresa->ruc); ?>"
                                data-telefono ="<?php echo e($empresa->telefono); ?>"
                                data-correo ="<?php echo e($empresa->correo); ?>"
                                >Editar</button>
                                
                                <button data-id="<?php echo e($empresa->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="empresa_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_empresa">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_empresa" action="<?php echo e(url('mantenimiento/empresa')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                   
                    Nombre: <input type="text" name="nombre" id="nombre" class="form-control">
                    Razon_social: <input type="text" name="razon_social" id="razon_social" class="form-control">
                    <div class="form-group">
                        Departamento:
                            <select name="departamento_id" id = "departamento_id" class="form-control">
                                <option>Elige</option>
                                <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <option value="<?php echo e($departamento->id); ?>"><?php echo e($departamento->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        Provincia:
                            <select name="provincia_id" id="provincia_id" class="form-control">
                                
                            </select>
                    </div>
                    <div class="form-group">
                    Distrito 
                        <select class="form-control" name="distrito_id" id="distrito_id">
                            
                        </select>
                    </div>
                    <div class="form-group">
                    Dirección: <input type="text" name="direccion" id="direccion" class="form-control">
                    </div>
                    <div class="form-group">
                    Ruc: <input type="text" maxlength="11" name="ruc" id="ruc" class="form-control"
                    onkeypress="ValidaSoloNumeros();">
                    </div>
                    <div class="form-group">
                    Teléfono: <input type="text" name="telefono" id="telefono" class="form-control">
                    </div>
                    <div class="form-group">
                    Correo: <input type="email" name="correo" id="correo" class="form-control">
                    </div>
                    <div class="form-group">
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_empresa" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/empresa/index.blade.php ENDPATH**/ ?>