<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
</html>
<?php /**PATH C:\xampp\htdocs\sisperu\resources\views/layouts/default.blade.php ENDPATH**/ ?>