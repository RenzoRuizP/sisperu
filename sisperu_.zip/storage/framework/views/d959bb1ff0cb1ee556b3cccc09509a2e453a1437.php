 
 

<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_trabajador"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>CARGO</th>
                        <th>EMPRESA</th>
                        <th>SUCURSAL</th>
                        <th>PLANILLA</th>
                        <th>HORAS TRABAJADAS</th>
                        <th>SUELDO</th>
                        <th>TIEMPO DE REFRIGERIO</th>
                        <th>PERSONA</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $trabajadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($trabajador->id); ?></td>
                            <td><?php echo e($trabajador->cargo->nombre); ?></td>
                            <td><?php echo e($trabajador->empresa->nombre); ?></td>
                            <td><?php echo e($trabajador->sucursal->nombre); ?></td>
                            <td><?php echo e($trabajador->planilla); ?></td>
                            <td><?php echo e($trabajador->horas_trabajo); ?></td>
                            <td><?php echo e($trabajador->sueldo); ?></td>
                            <td><?php echo e($trabajador->tiempo_refrigerio); ?></td>
                            <td>
                                <?php echo e($trabajador->persona->nombres.' '.$trabajador->persona->apellidos); ?>

                            </td>
                            <td>
                                <button class="btn btn-success btn-editar" 
                                data-id="<?php echo e($trabajador->id); ?>" 
                                data-cargo_id="<?php echo e($trabajador->cargo_id); ?>" 
                                data-empresa_id="<?php echo e($trabajador->empresa_id); ?>" 
                                data-sucursal_id ="<?php echo e($trabajador->sucursal_id); ?>"
                                data-planilla ="<?php echo e($trabajador->planilla); ?>"
                                data-horas_trabajo ="<?php echo e($trabajador->horas_trabajo); ?>"
                                data-sueldo ="<?php echo e($trabajador->sueldo); ?>"
                                data-tiempo_refrigerio ="<?php echo e($trabajador->tiempo_refrigerio); ?>"
                                data-persona_id ="<?php echo e($trabajador->persona_id); ?>"
                                >Editar</button>
                                
                                <button data-id="<?php echo e($trabajador->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="trabajador_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_trabajador">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_trabajador" action="<?php echo e(url('mantenimiento/trabajador')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">

                    <div class="form-group">
                    Cargo   <select class="form-control" name="cargo_id" id="cargo_id">
                                <option>Elige</option>                        
                                <?php $__currentLoopData = $cargos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cargo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($cargo->id); ?>"><?php echo e($cargo->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        Empresa ID
                            <select name="empresa_id" class="form-control">
                                <option>Elige</option>
                                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($empresa->id); ?>"><?php echo e($empresa->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        Sucursal <select id="sucursal_id" name= "sucursal_id" class="form-control">
                                <option>Elige</option>
                                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sucursal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>;
                                    <option value="<?php echo e($sucursal->id); ?>"><?php echo e($sucursal->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                    </div>
                    <div class="form-group">
                        planilla: <input type="text" name="planilla" maxlength="1" class="form-control" onkeypress="ValidaSoloNumeros();">
                    </div>
                    <div class="form-group">
                        Sueldo: <input type="text" name="sueldo" class="form-control">
                    </div>
                    <div class="form-group">
                        Horas de trabajo: <input type="text" name="horas_trabajo" class="form-control">
                    </div>
                    <div class="form-group">
                        Tiempo refrigerio: <input type="text" name="tiempo_refrigerio" class="form-control">
                    </div>
                    <div class="form-group">
                        Persona
                            <select class="form-control" name="persona_id">
                                <option>Elige</option>
                                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option value="<?php echo e($persona->id); ?>"><?php echo e($persona->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                         
                    </div>
                   
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_trabajador" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/trabajador/index.blade.php ENDPATH**/ ?>