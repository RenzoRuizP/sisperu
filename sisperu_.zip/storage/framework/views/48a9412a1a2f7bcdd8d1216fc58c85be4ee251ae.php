<?php $__env->startSection('content'); ?>


<div class="">
    <div class="row">
        <div class="col-4">
            <button class="btn btn-primary" data-toggle = "modal" data-target="#modal_paciente"> Modal
            </button>
        </div>
        <div class="card col-12">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>TIPO PACIENTE</th>
                        <th>NOMBRE PERSONA</th>
                        <th>ACCIONES</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($paciente->id); ?></td>
                            
                                <?php

                                    if($paciente->tipo_paciente == 1)
                                        echo '<td>ACTIVO LABORAL</td>';
                                    if($paciente->tipo_paciente == 2)
                                        echo '<td>JUBILADO COMPLACIENTE</td>';
                                    if($paciente->tipo_paciente == 3)
                                        echo '<td>NIÑO</td>';
                                    if($paciente->tipo_paciente == 4)
                                        echo '<td>CC</td>';
                                    if($paciente->tipo_paciente == 5)
                                        echo '<td>IP</td>';
                                ?>
                         
                            <td><?php echo e($paciente->persona->nombres); ?></td>
                            <td>
                                <button class="btn btn-success btn-editar" data-id="<?php echo e($paciente->id); ?>" data-tipo_paciente="<?php echo e($paciente->tipo_paciente); ?>">Editar</button>
                                <button data-id="<?php echo e($paciente->id); ?>" class="btn btn-danger btn-eliminar">Eliminar</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <form method="post" id="paciente_eliminar">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>

        <div class="modal" tabindex="-1" role="dialog" id="modal_paciente">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="registrar_paciente" action="<?php echo e(url('mantenimiento/paciente')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                  <div class="modal-header">
                    <h5 class="modal-title">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div class="modal-body">
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <select name="tipo_paciente" class="form-control">
                                <option>- Elige - </option>
                                <?php $__currentLoopData = $tiposPacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tipoPaciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($tipoPaciente); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <select class="form-control" name="persona_id" id="persona_id">
                                <option>Elige persona</option>
                                
                                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($persona->id); ?>"><?php echo e($persona->nombres); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" id="guardar_paciente" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  </div>
                </form>
            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sisperu_\resources\views/admin/paciente/index.blade.php ENDPATH**/ ?>