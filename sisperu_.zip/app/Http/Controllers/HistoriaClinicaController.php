<?php

namespace App\Http\Controllers;

use App\Paciente;
use App\Persona;
use Illuminate\Http\Request;

class HistoriaClinicaController extends Controller
{
    public function evolucion(Paciente $paciente = null){
    	$estadosCiviles = Persona::getEstadoCivil();
    	//$cliente = Cliente::whereNull()->get();
    	$tiposPacientes = Paciente::getTipoPaciente();
    	//dd($tiposPacientes);
    	$js = [];
    	return view("admin.historia-clinica.evolucion", compact('js', 'paciente', 'estadosCiviles', 'tiposPacientes'));
    }
}
