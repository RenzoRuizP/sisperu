<!-- bundle -->
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/app.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Datatables js -->
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/jquery.dataTables.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/sweetalert2.js?v=2"></script>
    <!-- plugin js -->
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/summernote-bs4.min.js"></script>
    <!-- Summernote demo -->
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/pages/demo.summernote.js?v=1"></script>
    <!-- Js Tree -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/moment.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/buttons.pdfmake.min.js"></script>
    <!-- <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/buttons.vfs_fonts.js"></script> -->
    <!-- <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/buttons.jszip.min.js"></script> -->
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
    <script type="text/javascript" src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/fullcalendar.min.js"></script>
    <script type="text/javascript" src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/locale-all.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/dataTables.responsive.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/responsive.bootstrap4.min.js"></script>
    <script type="text/javascript" src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/tooltipster.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/css/vendor/tooltipster.bundle.min.css">
    <link rel="stylesheet" type="text/css" href="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/css/vendor/plugins/tooltipster/sideTip/themes/tooltipster-sideTip-shadow.min.css">
    <link rel="stylesheet" type="text/css" href="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/source/jquery.fancybox.css" media="screen" />
    <script type="text/javascript" src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/source/jquery.fancybox.pack.js"></script>
    <script type="text/javascript" src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/tinymce/jquery.tinymce.min.js"></script>
    <script type="text/javascript" src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/tinymce/tinymce.min.js"></script>
    <!-- <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/bootstrap-datetimepicker.js"></script> -->
    <script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.13/dataRender/datetime.js"></script>
    <!--*******boostrap select js****-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <!-- third party js ends -->
    <!--*******ladda****-->
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/ladda/spin.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/vendor/ladda/ladda.min.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/pedido.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/producto.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/proforma.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/admin/admin.js?v=1.3"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/demo.js"></script>
    <script src="https://sisperu.net/sistema/aplication/view/TPL2020/publicroot/js/myjs.js?v=2.1"></script>
    <!-- demo app -->
    <!-- end demo js-->
    <script type="text/javascript" src="{{asset('js/base.js')}}"></script>
    <script type="text/javascript" src="{{asset('js/jquery-ui.min.js')}}"></script>